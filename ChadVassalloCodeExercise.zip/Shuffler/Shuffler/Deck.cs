﻿using System;
using System.Collections.Generic;

namespace Shuffler
{
    public class Deck
    {
        private static Random _rng = new Random();
        private Card[] _deck = new Card[sizeOfDeck];
        public const int sizeOfDeck = 52;
        public const int numberOfSuits = 4;
        public const int cardsPerSuit = 13;

        public Deck()
        {
            // initialize _deck as ordered by default
            OrderedDeck();
        }
        public Card[] OrderedDeck()
        {
            for (int i = 0; i < numberOfSuits; i++)
            {
                for (int j = 0; j < cardsPerSuit; j++)
                {
                    int position = i * cardsPerSuit + j;
                    _deck[position] = new Card() { Suit = (CardSuit)i, Value = (CardValue)j };
                }
            }
            return _deck;
        }
        public Card[] ShuffleDeck()
        {
            for (int i = _deck.Length - 1; i > 0; --i)
            {
                int j = _rng.Next(i + 1);
                Card temp = _deck[i];
                _deck[i] = _deck[j];
                _deck[j] = temp;
            }
            return _deck;
        }
    }
}
