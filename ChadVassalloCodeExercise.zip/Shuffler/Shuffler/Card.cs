﻿using System;

namespace Shuffler
{
    public enum CardSuit
    {
        Clubs, 
        Diamonds,
        Hearts,
        Spades
    }

    public enum CardValue
    { 
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Ace
    }

    public class Card
    {
        public CardSuit Suit { get; set; }
        public CardValue Value { get; set; }
    }
}