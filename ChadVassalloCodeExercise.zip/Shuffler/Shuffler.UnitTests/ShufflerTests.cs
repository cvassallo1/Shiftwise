using Shuffler;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Shuffler.UnitTests
{
    [TestClass]
    public class ShufflerTests
    {
        [TestMethod]
        public void TestOrderedDeck()
        {
            var deck = new Deck();
            deck.ShuffleDeck();
            var cards = deck.OrderedDeck();
            Assert.AreEqual(Deck.sizeOfDeck, cards.Length);
            Assert.AreEqual(CardSuit.Clubs, cards[0].Suit);
            Assert.AreEqual(CardValue.Two, cards[0].Value);
            Assert.AreEqual(CardSuit.Diamonds, cards[14].Suit);
            Assert.AreEqual(CardValue.Three, cards[14].Value);
            Assert.AreEqual(CardSuit.Hearts, cards[37].Suit);
            Assert.AreEqual(CardValue.King, cards[37].Value);
            Assert.AreEqual(CardSuit.Spades, cards[51].Suit);
            Assert.AreEqual(CardValue.Ace, cards[51].Value);
        }

        [TestMethod]
        public void TestShuffledDeck()
        {
            var deck = new Deck();
            int twoOfHeartsInFirstPosition = 0;
            int twoOfHeartsInTwentyFirstPosition = 0;
            int twoOfHeartsInLastPosition = 0;
            int aceOfDiamondsInFirstPosition = 0;
            int aceOfDiamondsInTwentyFirstPosition = 0;
            int aceOfDiamondsInLastPosition = 0;
            int numberOfShuffles = 1040;
            int minOccurrences = 10;
            int maxOccurrences = 30;
            for (int i = 0; i < numberOfShuffles; i++)
            {
                var cards = deck.ShuffleDeck();
                Assert.AreEqual(Deck.sizeOfDeck, cards.Length);
                if ((cards[0].Suit == CardSuit.Hearts)
                    && (cards[0].Value == CardValue.Two))
                {
                    twoOfHeartsInFirstPosition++;
                }
                else if ((cards[20].Suit == CardSuit.Hearts)
                    && (cards[20].Value == CardValue.Two))
                {
                    twoOfHeartsInTwentyFirstPosition++;
                }
                else if ((cards[Deck.sizeOfDeck - 1].Suit == CardSuit.Hearts)
                    && (cards[Deck.sizeOfDeck - 1].Value == CardValue.Two))
                {
                    twoOfHeartsInLastPosition++;
                }
                else if ((cards[0].Suit == CardSuit.Diamonds)
                    && (cards[0].Value == CardValue.Ace))
                {
                    aceOfDiamondsInFirstPosition++;
                }
                else if ((cards[20].Suit == CardSuit.Diamonds)
                    && (cards[20].Value == CardValue.Ace))
                {
                    aceOfDiamondsInTwentyFirstPosition++;
                }
                else if ((cards[Deck.sizeOfDeck - 1].Suit == CardSuit.Diamonds)
                    && (cards[Deck.sizeOfDeck - 1].Value == CardValue.Ace))
                {
                    aceOfDiamondsInLastPosition++;
                }
            }
            Assert.IsTrue(aceOfDiamondsInFirstPosition >= minOccurrences);
            Assert.IsTrue(aceOfDiamondsInFirstPosition <= maxOccurrences);
            Assert.IsTrue(aceOfDiamondsInTwentyFirstPosition >= minOccurrences);
            Assert.IsTrue(aceOfDiamondsInTwentyFirstPosition <= maxOccurrences);
            Assert.IsTrue(aceOfDiamondsInLastPosition >= minOccurrences);
            Assert.IsTrue(aceOfDiamondsInLastPosition <= maxOccurrences);
        }
    }
}
